import"./DNndiO2r.js";const r=""+new URL("logo.bMAZX8os.png",import.meta.url).href;export{r as _};
