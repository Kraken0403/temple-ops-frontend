import"./DNndiO2r.js";const p=""+new URL("sample-2.B1a39yd0.webp",import.meta.url).href;export{p as b};
