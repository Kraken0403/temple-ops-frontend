import"./DNndiO2r.js";const p=""+new URL("sample.CHGFatvC.png",import.meta.url).href;export{p as s};
