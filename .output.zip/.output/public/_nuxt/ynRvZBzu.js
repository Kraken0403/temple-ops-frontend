import"./DNndiO2r.js";const e=""+new URL("pdf.worker.BQQyum15.mjs",import.meta.url).href;export{e as default};
