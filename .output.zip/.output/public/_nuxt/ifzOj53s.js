import"./DNndiO2r.js";const r=""+new URL("sample-2.Dl_Uvqvw.png",import.meta.url).href;export{r as h};
